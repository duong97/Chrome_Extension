/*  chrome.tabs.executeScript({
    file: 'myscript.js'
  }); 
*/