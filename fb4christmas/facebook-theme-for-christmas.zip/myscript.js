var btn = document.createElement("img");
btn.className = "onggianoelbay";
btn.src = "https://vignette.wikia.nocookie.net/icarly/images/5/51/Animated-santa-reindeer.gif/revision/latest?cb=20111125195748";
document.body.appendChild(btn);